/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Violent Crimes 
 * Created on June 25, 2015, 12:21 PM
 */

//System Libraries 
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants
const float CNVPCT=100;//Conversion to percent 

//Function Prototype 

//Execution Begins Here!
int main(int argc, char** argv) {
   
    //Declare variables 
    float USpop=318;// United States population 
    float Brtpop= 64.1;// Britain population 
    float Brtcrm=6.52;// Violent crimes in Britain  
    float Uscrm=11.88;// Violent crimes in United States
    float pctBrt;  // percent violent crimes Britain 
    float pctUs; //  percent violent crimes United States 
    //Calculate percent of crime%
    pctBrt=Brtcrm/Brtpop*CNVPCT;
    pctUs=Uscrm/USpop*CNVPCT; 
    //Output the results 
    cout<<"The percent of crime %"<<endl; 
    cout<<"Percent of crime in United States = "
            <<fixed<<setprecision(2)<<pctUs<<"%"<<endl;
    cout<<"Percent of crime in Britain = "<<pctBrt<<"%"<<endl;
    //Exit stage right!
    
    return 0;
}

