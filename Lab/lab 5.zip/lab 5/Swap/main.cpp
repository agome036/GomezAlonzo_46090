/* 
 * File:   main.cpp
 * Author: rcc
 * Purpose: How to swap 
 * Created on June 29, 2015, 12:59 PM
 */

//System Libraries 
#include <iostream>
using namespace std;

//User Libraries 

//Global Constants 

//Function Prototypes 

//Execution Begins Here 
int main(int argc, char** argv) {
    //Declare Variables 
    int a,b;
    int min=10, max=100;
    
    //Input the values for a and b 
    cout<<"Input 2 integer values between "<<min<<"and ";
    cout<<max<<endl;
    cin>>a>>b; 
    
    
    //Validate the results 
    if(a>=min && a <=max && b>=min && b<=max){
        //Prompt the user for which swap 
         cout<<"What swap would you like to choose?"<<endl;
        cout<<"Storage -> s or in-place -> i"<<endl;
        //Declare the variable type 
        char type; 
        cin>>type;
        switch(type){
        case 's':{
            int temp=a;
            a=b;
            b=temp;
            cout<<"type is visible due to scope!"<<endl;
            cout<<"type ="<<type<<endl; 
            break;
            }
            case 'i':{
            a=a^b;
            b=a^b;
            a=a^b;
            }
        default: cout<<"You dont follow instructions"<<endl;
        
    }
    }else{
        cout<<"You dont follow instructions"<<endl;
        cout<<"No swap for you"<<endl;
        return 1;
    }
    //Output the results for the swap 
    cout<<"old a ="<<b<<",new a= "<<a<<endl;
    cout<<"old b="<<a<<", new a="<<b<<endl;
    
    //Exit stage right 
    
    return 0;
    }
