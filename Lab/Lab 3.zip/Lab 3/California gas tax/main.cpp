/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Find total tax paid per gallon 
 * Created on June 24, 2015, 1:30 PM
 */


#include <iostream> //I/O Library 
using namespace std;// Namespace for iostream

//System Libraries 

//Global Constants

//Function Prototype 

//Execution Begins Here!
/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variables 
    float pGalGas=3.69f;//Price per gallon of gas 
    float Caltax=.38:// california tax 
    float Fedtax=.18:// federal tax 
    float caSaltx=.08f:// california sale tax 
    float Totalt,poftax; // total tax paid and percentage 
    float slsTxV; //Sales tax values $'s 
    //calculate total tax 
    //Assumes no double taxation 
    slsTxV=(pGalGas-caltax-Fedtax)*(1-1/(1+slsTxV));
    Totalt=Fedtax+Caltax+slsTxV;
    poftax=Totalt/pGalGas*100;
    //Output the results 
    cout<<"The total tax on a gallon of gas @ $";
    cout<<"The percentage tax ="<<poftax<<"%"<<endl;
    //Exit stage right 
    return 0;
}

