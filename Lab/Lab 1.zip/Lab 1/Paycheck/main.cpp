/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: First Program to calculate paycheck 
 * Created on June 23, 2015, 10:39 PM
 */

//System Libraries 
#include <iostream> //File I/O

using namespace std; //std namespace -> iostream

//User Libraries 

//Global constants 

//Function Prototype 

//Execution begins here! 
int main(int argc, char** argv) {
    //Declare variables here
    float hours,rate,pay;
    //Input Values Here
    hours=40.0f;//Hours worked units=hours 
    rate=1e1f; //Pay rate  Units=$'s/hour 
    //Process Input Here 
    pay=rate*hours;//Units=$'s
    //Output Unknowns Here 
    cout<<"Hours work ="<<hours<<"(hrs)"<<endl;
    cout<<"Pay rate =$"<<rate<<"/(hrs)"<<endl;
    cout<<"My paycheck =$"<<pay<<endl;
    //Exit Stage Right 
    return 0;
}

