/* 
 * File:   Hello World 
 * Author: Alonzo Gomez 
 * Purpose: First Program to test IDE 
 * Created on June 22, 2015, 9:04 PM
 */

//System Libraries 
#include<iostream> //File I/O
using namespace std; //std namespace -> iostream 

  //User Libraries 

  //Global constants 

  //Function prototypes 

  //Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables Here 
    
    //Input Values Here 
    
    //Process Input Here 
    
    //Output Unknowns Here 
    cout<<"Hello World"<<endl;
    //Exit Stage Right!
    return 0;
}

