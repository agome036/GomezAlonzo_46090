/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose:Math tutor 
 * Created on June 30, 2015, 1:05 PM
 */

//System Libraries 
#include <iostream>
#include<iomanip>
#include<cstdlib>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables 
    unsigned short op1, op2, result;
    bool doAgain;
    
    //Loop base upon continuing to play with the math tutor
    do{
    //Determine the op1/op2
    op1=rand()%900+100;//[100-999];
    op2=rand()%900+100;//[100-999];
    //Display the problem 
    cout<<setw(6)<<op1<<endl;
    cout<<" + "<<op2<<endl;
    cout<<"-------"<<endl;
    //Input the value for the sum 
    cin>>result;
    //If correct output Congratulations else try 
    if( result ==op1+op2){
        cout<<endl<<"Congratulations"<<endl;
    }else{
        cout<<endl<<"Wrong Answer"<<endl;
        
    }
    //Prompt if they would like to continue 
    cout<<endl<<"Would you like to continue y/n";
            char response;
    cin>>response;
    if(response=='y')doAgain=true;
    else doAgain=false;
}while (doAgain);

//Exit stage right!

    return 0;
}

