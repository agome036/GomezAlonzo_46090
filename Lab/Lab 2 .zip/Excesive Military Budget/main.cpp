/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Military Budget 
 * Created on June 23, 2015, 1:37 PM
 */

//System Libraries 
#include <iostream> //I/O
using namespace std;//Namespace for iostream 

//User Libraries 

//Global Constants
const float CNVPCT=100.0f;//conversion 
//Function Prototypes 

//Execution Begins Here! 

int main(int argc, char** argv) {
    //Declare and Initialize variables 
    float fedBudg=3.9;// Number of custom
    float milBudg=.598;// Number of custom
    float pmlbudg; //percent military budget 
    //Calculate percent of budget for military 
    pmlbudg=milBudg/fedBudg*CNVPCT;
    //Outputresults 
    cout<<"percent of budget for military="<<pmlbudg<<endl;
    return 0;
}

