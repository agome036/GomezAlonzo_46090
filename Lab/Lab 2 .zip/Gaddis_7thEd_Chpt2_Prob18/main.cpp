/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Homework, Energy Drinkers 
 * Created on June 24, 2015, 10:33 AM
 */

//System Libraries 
#include <iostream> //I/O Library 
using namespace std;//Namespce for iostream

//User Libraries 

//Global Constants 
const float CNVPCT=100.0f;//Conversion 

//Function Prototype

//Execution Begins Here!
int main(int argc, char** argv) {
        //Declare and Initialize Variables 
        unsigned short cSurv=12467;//Number of customers surveyed 
        unsigned short nEDrnks;  //Number of customers drinking 1 or more energy drinks 
        unsigned short nCDrnks;  //Number of energy drinkers that prefer citrus flavor
        unsigned char pEDrnks=14; //Percent surveyed that prefer energy drinks 
        unsigned char pCDrnks=64; //Percent of energy drinkers that prefer citrus 
        //Calculate the number of Drinkers 
        nEDrnks=cSurv*pEDrnks/CNVPCT;
        nCDrnks=nEDrnks*pCDrnks/CNVPCT;
        //Output the results 
        cout<<"Number of Energy Drinkers ="<<nEDrnks<<endl;
        cout<<"Number of Citrus Drinkers ="<<nCDrnks<<endl;
        return 0;
}

