/* 
 * File:   main.cpp
 * Author: martingomez
 * Purpose: Homework, CS is cool 
 * Created on June 27, 2015, 6:28 PM
 */

//System Libraries 
#include <iostream> //I/O Library 
#include <stdio.h>
using namespace std;//Namespace for iostream 


//User Libraries 

//Global Constants 

//Function Prototype 

//Execution Begins Here! 
int main(int argc, char** argv) {
    
    cout<<"**************************************************"<<endl; 
    cout<<endl; 
    cout<<"    CCC        SSSS           !!"<<endl; 
    cout<<"   C   C      S    S          !!"<<endl; 
    cout<<"  C          S                !!"<<endl; 
    cout<<" C           S                !!"<<endl;
    cout<<" C             SSS            !!"<<endl;
    cout<<" C                  S         !!"<<endl;
    cout<<"  C                  S        !!"<<endl;
    cout<<"   C     C    S     S           "<<endl; 
    cout<<"     CCC        SSS           00"<<endl;
    cout<<endl;
    cout<<"**************************************************"<<endl; 
    cout<<"Computer Science is Cool Stuff !!! "<<endl;        
    //Exit stage right!
    
    return 0;\
}

