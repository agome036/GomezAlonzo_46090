/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: homework, counting coins 
 * Created on June 27, 2015, 8:38 PM
 */

//System Libraries 
#include <iostream> //I/O Library
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype 

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables 
    float number_of_Q, number_of_D, number_of_N, total_sum;
    cout<<"Press return after entering a number"<<endl;
    cout<<"Enter the number of Q"<<endl;
    cin>>number_of_Q;
    cout<<"Enter the number of D"<<endl;
    cin>>number_of_D;
    cout<<"Enter the number of N"<<endl; 
    cin>>number_of_N;
            
    //Calculate total sum 
    total_sum=number_of_Q*.25+number_of_D*.10+number_of_N*.05; 
    cout<<"total sum"<<endl;
    cout<<total_sum<<"cents$"<<endl; 
    return 0;
}

