/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Homework, Adding and multiplying 
 * Created on June 27, 2015, 7:00 PM
 */

#include <iostream> //I/O Library 
using namespace std;

//User Libraries 

//Global Constants 

//Function Prototype 

//Execution Begins Here! 
int main(int argc, char** argv) {
    //Decalre Variable 
    int number_of_A, number_of_B, total_sum,total_product;
    cout<<"Press return after entering a number"<<endl; 
    cout<<" Enter the number of A"<<endl;
    cin>>number_of_A;
    cout<<"Enter the number of B"<<endl;
    cin>>number_of_B;
    
    //calculate total sum and product 
    total_sum=number_of_A+number_of_B;
    total_product=number_of_A*number_of_B;
    cout<<"total product ="<<endl;cout<<total_product<<endl;
    cout<<"Total sum ="<<endl;cout<<total_sum <<endl;
    
    
    
            
    
    return 0;
}

