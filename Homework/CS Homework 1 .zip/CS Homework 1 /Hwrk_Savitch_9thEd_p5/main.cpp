/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Homework, letter 
 * Created on June 27, 2015, 10:16 PM
 */

//System Libraries 
#include <iostream>
using namespace std; //I/O Library 

//User Libraries 

//Global constants 

//Function Prototype

//Execution starts here!
int main(int argc, char** argv) {
    char variable; 
    cin>>variable; 
    cout<<" "           <<variable<<variable<< variable<<" "<<endl; 
    cout<<" "<<variable<< " "                <<variable<<" "<<endl; 
    cout<<" "<<variable<<"                                  "<<endl; 
    cout<<" "<<variable<<"                                      "<<endl;
    cout<<" "<<variable<< "                                      "<<endl; 
    cout<<" "<<variable<< "                                      "<<endl;
    cout<<" "<<variable<< "                                      "<<endl; 
    cout<<" "     <<variable<<" "       <<variable<< "       "<<endl; 
    cout<<" "<<     variable<< variable<<variable<<"  "<<endl; 
    return 0; 
}

