/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Retroactive pay in months 
 * Created on July 6, 2015, 9:11 PM
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype

//Execution begins her
int main(int argc, char** argv) {
    //Declare variables
    float prvsal, retroinc=.076, newYr, newMont, retropay, num_mont;
    
    cout<<" Enter employee previous yearly salary"<<endl;
    cin>>prvsal;// In dollars 
    cout<<"Enter number of months";
    cin>>num_mont; //number of months 
    
    //calculate amount of retroactive pay, new yearly salary, and monthly salary 
    retropay=(num_mont/12)*prvsal*retroinc ;
    //Output results
    cout<<"Amount grossed by retroactive pay monthly"<<endl;
    cout<<retropay<<"$"<<endl; 
    
    return 0;
}

