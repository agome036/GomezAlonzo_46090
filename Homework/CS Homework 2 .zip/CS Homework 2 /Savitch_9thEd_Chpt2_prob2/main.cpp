/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Retroactive pay 
 * Created on July 6, 2015, 9:11 PM
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype

//Execution begins her
int main(int argc, char** argv) {
    //Declare variables
    float prvsal, retroinc=.076, newYr, newMont, retropay;
    
    cout<<" Enter employee previous yearly salary"<<endl;
    cin>>prvsal;// In dollars 
    
    //calculate amount of retroactive pay, new yearly salary, and monthly salary 
    retropay=0.5*prvsal*retroinc ;
    newYr= (0.5*prvsal*retroinc)+(0.5*prvsal);
    newMont=newYr/12;
    
    //Output results
    cout<<"Amount grossed by retroactive pay"<<endl;
    cout<<retropay<<"$"<<endl; 
    cout<<"New annual salary"<<endl;
    cout<<newYr<<"$"<<endl; 
    cout<<"New monthly salary"<<endl; 
    cout<<newMont<<"$"<<endl; 
    return 0;
}

