/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: ounces to metric ton 
 * Created on July 6, 2015, 12:39 AM
 */

//System Libraries 
#include <iostream>
using namespace std;

//User Library 

//Global Constants 
const float metric_ton=35273.92f;//conversion to metric ton
// Function Prototypes 

//Execution Begins Here!
int main(int argc, char** argv) {

    //Declare variables 
    float weight_of_cereal, metric ,oz, num_box ;
    
    //Prompt then input 
    cout<<"Enter weight of breakfast cereal in ounces"<<endl;
    cin>>weight_of_cereal;
    
    //Calculate 
    metric=weight_of_cereal/metric_ton ; 
    num_box=metric; 
    
    cout<<"Conversion to metric ton"<<endl; 
    cout<<metric<<"metric tons "<<endl; 
    cout<<"number of boxes needed for 1 metric ton"<<endl;
    cout<<num_box<<endl;
    
    //Exit stage right !
    return 0;
}

