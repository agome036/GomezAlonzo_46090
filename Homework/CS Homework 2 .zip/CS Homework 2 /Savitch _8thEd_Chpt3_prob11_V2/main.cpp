/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Approximate e^x with an infinite sequence  
 * Created on July 2, 2015, 12:11 PM
 */

//System Libraries 
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries 

//Global Constants 

//Function Prototype 

//Execution begins here!
int main(int argc, char** argv) {
    //Declare our variables 
    float x=2.0f;
    float ex=1.0f;
    float delt=1.0f;
    float tol=1e-7;//Determine the accuracy for the approximation 
    
    //Utilize a for-loop to calculate e^x 
    for (int term=1;delt<-tol||delt>tol;delt*=x/term,ex+=delt,term++){}
    float fact=1;
   

//Output the results 
cout<<fixed<<showpoint<<setprecision(15)<<endl; 
cout<<"Exact e("<<x<<")="<<exp(x)<<endl;
cout<<"Approx e("<<x<<")="<<ex<<endl;

//Exit stage right 
return 0;
}


