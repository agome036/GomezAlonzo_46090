/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Reformatting 
 * Created on July 6, 2015, 11:35 AM
 */

//System Libraries 
#include <iostream>
using namespace std;

//User Library 
 
//Global Constants

//Function Prototype

//Execution begins here!
int main(int argc, char** argv) 
{
    //Declare variables
    double radius, vm;
    cout<<"Enter radius of a sphere."<<endl; 
    cin >>radius;
    
    //Calculate volume 
    vm =(4.0/3.0)*3.1415 * radius*radius*radius;
   
    //Output the volume 
   cout<<"The volume is "<< vm <<endl; 
    return 0;
}
 