/* 
 * File:   main.cpp
 * Author: Alonzo Gomez
 * Purpose: calculate loans 
 * Created on July 6, 2015, 10:34 PM
 */

//System Libraries 
#include <iostream> // I/O Library 
using namespace std;

//User Libraries 

//Global constants 
 
//Function Prototype 

//Execution begins here! 
int main(int argc, char** argv) {
    //Declare variables 
    float amt_need, int_rate, dur_time, face_val, month_pay;
    
    cout<<"Amount customer needed to receive"<<endl;
    cin>>amt_need; 
    cout<<"Interest rate"<<"%"<<endl;
    cin>>int_rate;
    cout<<" Duration of loan"<<endl;
    cin>>dur_time; 
    cout<<"months"; 
    
    //Calculate face value & monthly payment, 
    face_val= amt_need+(int_rate*dur_time/12);
    month_pay= face_val/(dur_time/12) ;      
    
    cout<<"Face value "<<endl;
    cout<<face_val<<endl;
    cout<<"monthly payments";
    cout<<month_pay<<endl;
    return 0;
}

