/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: calculate monthly payment 
 * Created on July 1, 2015, 11:02 AM
 */

//System Libraries 
#include <iostream>
#include <iomanip>
using namespace std;

//User Library

//Global Constant 

//Function Prototype 

//Execution begins here!
int main(int argc, char** argv) {
    //Decalare variables 
    unsigned char nMonths=36;// Number of Months to payoff loan
    unsigned short loan=10000;//Loan amount in $'s 
    float ir=0.01f; //Interest rate per month
    float mnthPay; //Interest rate per Month 
    float temp=1.0f; //Intermediate value found in Monthly payment equation 
    float cstLoan; //Cost of the loan in $'s
    float totCost;    //Total paid back to lender 
    
    //Calculate the intermediate value 
    float onePlsi=(1+ir);
    for (int months =1;months<=nMonths;months++){
        temp*=onePlsi;
    }
    //Calculate the monthly payment 
    mnthPay=ir*temp*loan/(temp-1);
    totCost=nMonths*mnthPay;
    cstLoan=totCost-loan;
   //Output the results 
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout<<"Loan Amount:          $ "<<setw(8)<<loan*1.0f<<endl;
    cout<<"Monthly Interest Rate   "   <<setw(8)<<ir*100<<"%"<<endl;    
    cout<<"Number of payments      "<<setw(8)<<static_cast<int>(nMonths)<<endl;
    cout<<"Monthly Payment:       $"<<setw(8)<<mnthPay<<endl;
    cout<<"Amount paid back:      $"<<setw(8)<<totCost<<endl;
    cout<<"Interest paid:         $"<<setw(8)<<cstLoan<<endl;
            
           
   //Exit stage right!
    return 0;
}

