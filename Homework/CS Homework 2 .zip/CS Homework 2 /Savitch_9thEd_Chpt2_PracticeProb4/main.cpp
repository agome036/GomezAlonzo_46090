/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Mad lib 
 * Created on July 6, 2015, 10:05 AM
 */

//System Libraries 
#include <iostream>
using namespace std;

//User Library 

//Global Constants

//Function Prototype 

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    string variable_1,variable_2,variable_3,variable_4, variable_5,
     variable_6,variable_7;

    
    cout<<"The first or last name of your instructor"<<endl;
    cin>>variable_1;
    cout<<"Your name"<<endl;
    cin>>variable_2;
    cout<<"A food"<<endl;
    cin>>variable_3;
    cout<<"A number between 100 and 120"<<endl;
    cin>>variable_4;
    cout<<"An adjective"<<endl;
    cin>>variable_5;
    cout<<"A color"<<endl;
    cin>>variable_6;
    cout<<"An animal"<<endl;
    cin>>variable_7; 
    cout<<endl;
    cout<<"Dear Instructor "<<variable_1<<endl;
    cout<<endl;
    cout<<"I am sorry that I am unable to turn in my homework at this time."<<endl;
    cout<<"First I ate a rotten "<<variable_3<< ", which made me turn "<<variable_6<<endl;
    cout<<"and extremely ill. I came down with a fever of "<<variable_4<<" . Next my "<<variable_5<<endl; 
    cout<<"pet "<<variable_7<<" must have smelled the remains of the "<<variable_3<<endl;
    cout<<"on my homework , because he ate it. I am currently rewriting my homework and home you will accept it late."<<endl;
    cout<<endl; 
    cout<<"Sincerely,"<<endl;
    cout<<variable_2<<endl; 
    
    //Exit stage right!  
    
    return 0;
}

