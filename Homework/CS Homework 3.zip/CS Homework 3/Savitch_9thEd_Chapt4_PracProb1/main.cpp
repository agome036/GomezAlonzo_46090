/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Calculate miles per gallon 
 * Created on July 13, 2015, 12:11 AM
 */

//System Library
#include<iostream>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables 
    float gal, miles, lit,mpg;
    
    //Input values 
    cout<<"Input liters of gasoline consumed ="<<endl;
    cin>>lit; 
    cout<<"Liters comsumed ="<<lit<<endl; 
    cout<<"Enter number of miles traveled"<<endl;
    cin>>miles; 
    cout<<"miles traveled ="<<miles<<endl;
    
    //Convert liters to gallons 
    gal=lit*0.264179;
    mpg=miles/gal;
    
    //Output results 
   cout<<"Miles per gallon ="<<mpg<<"mpg"<<endl;
    
    return 0;
}

