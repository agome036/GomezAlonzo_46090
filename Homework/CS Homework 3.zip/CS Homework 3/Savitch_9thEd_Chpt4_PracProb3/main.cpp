/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose:Stocks 
 * Created on July 13, 2015, 1:44 AM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototype
float price_per(int whole, int numer, int denom, int total_shares);

//Execution Begins Here!
int main(int argc, char** argv) {
    
    char loop;


    do
    {
        //Declare variables 
        int number_of_shares, whole_value, numerator, denominator;
        float price_per_share;
        
        cout << "Enter the number of shares you own: ";
        cin >> number_of_shares;
        cout << "Enter the value of your shares, first the whole value: ";
        cin >> whole_value;
        cout << "Now enter the numerator: ";
        cin >> numerator;
        cout << "Now the denominator: ";
        cin >> denominator;

        //call
        price_per_share = price_per(whole_value, numerator, denominator, number_of_shares);
        
        //displays output
        cout << "The value of one share is: ";
        cout << price_per_share << endl;
        cout << "Enter Y to continue or N to exit: ";
        cin >> loop;

    }while (loop == 'Y' || loop == 'y');
    cout << "Finished" << endl;

}
//function definition
float price_per(int whole, int numer, int denom, int total_shares)
{

    float whole_denom_numer, last;

    whole_denom_numer = (((whole*denom)+numer)/denom);
    last = whole_denom_numer/total_shares;
    return last;
}
