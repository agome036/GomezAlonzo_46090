/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Converting length to meters
 * Created on July 13, 2015, 8:58 PM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global constants

//Function Prototype
float met( float metr  , float cent);
float cent( float ft );
//Execution Begins Here!
int main(int argc, char** argv) {
    char loop;
    do{
    //Declare variables 
    float inch, meter, centi; 
    int feet;
    cout<<" Enter length in meters and centimeters"<<endl; 
    cout<<" meters = "<<endl;
    cin>>meter; 
    cout<<" centimeters = "<<endl; 
    cin>>centi ;
    
    //Call function 
    feet=met(meter,centi);
    inch=cent(feet); 
    
    cout<<" converted to feet ="<<feet<<endl;
    cout<<" converted to inches="<<inch<<endl; 
    
    //Loop 
    
    cout<<"Enter Y to continue or N to exit"<<endl; 
        cin>>loop;
    
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
    
    return 0;
}
float met( float metr  , float cent){
    
    return(metr/.3048+((cent/100)/.3048));
}
float cent( float ft ){
    
    return(ft*12); 
}
