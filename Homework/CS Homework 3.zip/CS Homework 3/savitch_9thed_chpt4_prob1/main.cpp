/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: After tax cost of home 
 * Created on July 13, 2015, 12:51 PM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototype
float loan(float cost_home, float dpay);
float nwcst(float loan, float taxsav);
//Execution Begins Here
int main(int argc, char** argv) {
    char loop;
    do{
    //Declare variables 
    float cst_house,dwn_pay,loan_bal,tru_cst,tax_save=.09;
    
    //Input variables
    cout<<" Enter the cost of a house including tax = $"<<endl;
    cin>>cst_house;
    cout<<" Enter the down payment given = $"<<endl;
     cin>>dwn_pay; 
     
     //Calculate
     loan_bal=loan(cst_house,dwn_pay);       
     tru_cst=nwcst(loan_bal,tax_save);
     
     cout<<"Loan balance = $"<<loan_bal<<endl;
     loan_bal=loan(cst_house,dwn_pay);
     cout<<"Tax savings = $"<<tax_save<<endl;
             
     cout<<"Acutal cost of house =$"<<tru_cst<<endl; 
     cout<<"Enter Y to continue or N to exit"<<endl; 
    cin>>loop;
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;

            
            
return 0;
}
float loan(float cost_home, float dpay){
    
    return(cost_home-dpay);
    
}
float nwcst(float loan, float taxsav){
    
    return(loan*taxsav);
}
