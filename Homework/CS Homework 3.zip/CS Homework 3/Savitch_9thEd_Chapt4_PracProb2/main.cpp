/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Calculate miles per gallon 
 * Created on July 13, 2015, 12:11 AM
 */

//System Library
#include<iostream>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables 
    float gal_1, miles_1, lit_1,mpg_1,mpg_2,car_1=mpg_1,car_2=mpg_2,
    gal_2,miles_2,lit_2;
    //Input values for car 1
    cout<<"Input liters of gasoline consumed by car 1 ="<<endl;
    cin>>lit_1; 
    cout<<"Liters comsumed ="<<lit_1<<endl; 
    cout<<"Enter number of miles traveled"<<endl;
    cin>>miles_1; 
    cout<<"miles traveled ="<<miles_1<<endl;
    
    //Input values for car 2
    cout<<"Input liters of gasoline consumed by car 2 ="<<endl;
    cin>>lit_2; 
    cout<<"Liters comsumed ="<<lit_2<<endl; 
    cout<<"Enter number of miles traveled"<<endl;
    cin>>miles_2; 
    cout<<"miles traveled ="<<miles_2<<endl;
   
    //Convert liters to gallons 
    gal_1=lit_1*0.264179;
    mpg_1=miles_1/gal_1;
    
    gal_2=lit_1*0.264179;
    mpg_2=miles_2/gal_2;
    //Output results 
   cout<<"Miles per gallon for car one ="<<mpg_1<<" mpg"<<endl;
   cout<<"Miles per gallon for car two ="<<mpg_2<<" mpg"<<endl;
    
   //if else statement 
   {
   if (mpg_1>mpg_2)
    cout<<" car 1 has the better fuel efficiency";
    else if(mpg_1<mpg_2);
   cout<<" car 2 has better fuel efficiency";
   }
    return 0;
}



