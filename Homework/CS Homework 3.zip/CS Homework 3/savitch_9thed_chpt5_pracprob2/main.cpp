/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Converting length to meters
 * Created on July 13, 2015, 8:21 PM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global constants

//Function Prototype
float met( int feet  , float inches);
float cent( float metr );
//Execution Begins Here!
int main(int argc, char** argv) {
    char loop;
    do{
    //Declare variables 
    float inch, meter, centi; 
    int feet;
    cout<<" Enter length in feet and inches"<<endl; 
    cout<<" feet = "<<endl;
    cin>>feet; 
    cout<<" inch = "<<endl; 
    cin>>inch ;
    
    //Call function 
    meter=met(inch,feet);
    centi=cent(meter); 
    
    cout<<" converted to meters ="<<meter<<endl;
    cout<<" converted to centimeters="<<centi<<endl; 
    
    //Loop 
    
    cout<<"Enter Y to continue or N to exit"<<endl; 
        cin>>loop;
    
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
    
    return 0;
}
float met( int ft , float inches){
    
    return((ft*.3048)+((inches/12)*.3048));
}
float cent( float metr ){
    
    return(metr*100); 
}
