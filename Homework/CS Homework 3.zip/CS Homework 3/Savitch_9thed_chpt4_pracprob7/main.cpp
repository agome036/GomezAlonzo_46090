/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Find gravitational force between two objects
 * Created on July 13, 2015, 10:16 AM
 */

//System Library
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries 

//Global Constants
const float GRAVITY=6.673e-8;//Gravitational constant
//Function Prototype 
float pre_force(float mas1, float mas2, float dis);
//Execution Begins Here!

int main(int argc, char** argv) {
   
    char loop; 
    do{
    //Declare variables  
    float mass_1, mass_2,final_force,dist;
    //Input variables 
    cout<<"Enter mass 1 in grams ="<<endl;
    cin>>mass_1; 
    cout<<"Enter mass 2 in grams ="<<endl; 
    cin>>mass_2; 
    cout<<"Enter the distance between two masses in centimeters ="<<endl;
    cin>>dist; 
   
    //Calculation 
    final_force=pre_force(mass_1,mass_2,dist);
    
    //Output 
    cout<<"Gravitational force ="<<final_force<<" g*cm/sec^2 "<<endl; 
    cout<<"Enter Y to continue or N to exit"<<endl; 
    cin>>loop;
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
     return 0;
}
float pre_force(float mas1, float mas2, float dis)
{
    return((mas1*mas2*GRAVITY)/pow(dis,2));
}


