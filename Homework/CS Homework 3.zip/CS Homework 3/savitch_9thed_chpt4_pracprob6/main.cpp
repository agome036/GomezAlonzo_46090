/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Calculate interest
 * Created on July 13, 2015, 11:58 AM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototype
float pre_int_rate(float int_rate,float int_rat,int num_mon);
//Execution Begins Here

int main(int argc, char** argv) {
    char loop;
    do{ 
        //Declare variables 
        float inti_bal, int_rate,final_int;
        int num_month;
        //Input variables 
        cout<<" Enter the initial balance = $"<<endl; 
        cin>>inti_bal; 
        cout<<" Enter the interest rate = %"<<endl;
        cin>>int_rate; 
        cout<<" Enter number of months left ="<<endl; 
        cin>>num_month; 
        
        //Calculate 
        final_int=pre_int_rate(inti_bal,int_rate,num_month);
        
        //Output
        cout<<" Interest owed = $"<<final_int<<endl;
        cout<<"Enter Y to continue or N to exit"<<endl; 
        cin>>loop;
    
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
    return 0;
}

float pre_int_rate(float int_rate,float int_rat,int num_mon)
{ 
    return(int_rate*int_rat*num_mon);
}