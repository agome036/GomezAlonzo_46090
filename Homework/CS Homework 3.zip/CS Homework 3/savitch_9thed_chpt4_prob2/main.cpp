/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Age weight and height measurements 
 * Created on July 13, 2015, 12:51 PM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototype
float hat(int weight, int height );
float jack(int weight, int height);
float waist(int weight);
//Execution Begins Here
int main(int argc, char** argv) {
    char loop; 
    do{
    //Declare variables 
    int hat_size, jak_size, waist_size,wt_lbs, ht_inch,age;
    
    //Input variables 
    cout<<" Enter age = years"<<endl;
    cin>>age; 
    cout<<" Enter weight = lbs"<<endl;
    cin>>wt_lbs;
    cout<<" Enter height = inches"<<endl; 
    cin>>ht_inch; 
    
    
    //Calculate 
    
    hat_size=hat(wt_lbs,ht_inch);
    cout<<" Hate size = "<<hat_size<<endl; 
    jak_size=jack(wt_lbs,ht_inch); 
    cout<<" Jacket size ="<<jak_size<<endl; 
    waist_size=waist(wt_lbs);
    cout<<" Waist size "<<waist_size<<endl;
    
    //loop 
    
    cout<<"Enter Y to continue or N to exit"<<endl; 
    cin>>loop;
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
    
    return 0;
}
float hat(int weight, int height ){
    
    return((weight/height)*2.9);
}
float jack(int weight, int height){
    
    return((height*weight)/288);
}
float waist(int weight){
    
    return(weight/5.7);
}