/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: combine practice problems 5&6
 * Created on July 13, 2015, 11:08 PM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global constants 

//Function Prototype
float kil(float wtpds, float wtounc);
float gra(float kil);
float wtpds(float kil, float oz);
float wtou(float wtpds);

//Execution Begins Here!
int main(int argc, char** argv) {
    char loop;
    do{
    //Declare variables 
    float wt_lbs,wt_ounc,kilo,gram,number;
    
    cout<<" Hello which conversion would you like?"<<endl; 
    cout<<" For the pounds to kilo conversion enter 1"<<endl;
    cout<<" For the kilo to pounds conversion enter 2"<<endl; 
    cin>>number; 
    
    if (number>1){
        //Input info 
        cout<<" Enter the weight in kilogram ="<<endl;
        cin>>kilo; 
        cout<<" Enter the weight in gram ="<<endl;
        cin>>gram; 
        
        //call function
        wt_lbs=wtpds(kilo,gram);
        wt_ounc=wtou(wt_lbs);
        
        //Output 
        cout<<" Converted to pounds ="<<wt_lbs<<endl;
        cout<<" Converted to ounces ="<<wt_ounc<<endl; 
    }else {
        cout<<" Enter the weight in pounds ="<<endl;
        cin>>wt_lbs; 
        cout<<" Enter the weight in ounces ="<<endl;
        cin>>wt_ounc; 
        
        //call function
        kilo=kil(wt_lbs,wt_ounc);
        gram=gra(kilo);
        
        //Output 
        cout<<" Converted to kilograms ="<<kilo<<endl;
        cout<<" Converted to grams ="<<gram<<endl; 
        
    }
    cout<<"Enter Y to continue or N to exit"<<endl; 
        cin>>loop;
    
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
    
    
return 0;
}
float kil(float wtpds, float wtounc){
       
       return(wtpds/2.2046+((wtounc/16)/2.2046));
   }
   float gra(float kil){
       
       return(kil*1000);
   }
   float wtpds(float kil, float gra){
       
       return(kil*2.2046+((gra/1000)*2.2046));
   }
   float wtou(float wtpds){
       
       return(wtpds*16);
   }