/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: combine practice problems 2&3 
 * Created on July 13, 2015, 10:25 PM
 */

//System Library
#include <iostream>
using namespace std;

//User Libraries

//Global constants 

//Function Prototype
float mets( float metr  , float cent);
float cents( float ft );
float met( int feet  , float inches);
float cent( float metr );
//Execution Begins Here!
int main(int argc, char** argv) {
    char loop;
    do{
    //Declare variables 
    float inch, meter, centi,number; 
    int feet;
    
    cout<<" Hello which conversion would you like?"<<endl; 
    cout<<" For the meters to feet conversion enter 1"<<endl;
    cout<<" For the feet to meters conversion enter 2"<<endl; 
    cin>>number; 
    
    if (number>1)
        //Input info 
    {cout<<" Enter length in feet and inches"<<endl; 
    cout<<" feet = "<<endl;
    cin>>feet; 
    cout<<" inch = "<<endl; 
    cin>>inch ;
    
    //call function 
    meter=met(inch,feet);
    centi=cent(meter); 
    
    cout<<" converted to meters ="<<meter<<endl;
    cout<<" converted to centimeters="<<centi<<endl; 
    
    } else {
        cout<<" Enter length in meters and centimeters"<<endl; 
    cout<<" meters = "<<endl;
    cin>>meter; 
    cout<<" centimeters = "<<endl; 
    cin>>centi ;
    
    //Call function 
    feet=mets(meter,centi);
    inch=cents(feet); 
    
    cout<<" converted to feet ="<<feet<<endl;
    cout<<" converted to inches="<<inch<<endl; 
    }
    cout<<"Enter Y to continue or N to exit"<<endl; 
        cin>>loop;
    
    }while(loop=='y' ||loop=='Y');
    cout<<"Finished"<<endl;
    
   return 0;
}
float mets( float metr  , float cent){
    
    return(metr/.3048+((cent/100)/.3048));
}
float cents( float ft ){
    
    return(ft*12); 
}
float met( int ft , float inches){
    
    return((ft*.3048)+((inches/12)*.3048));
}
float cent( float metr ){
    
    return(metr*100); 
}

