/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Inflation 
 * Created on July 13, 2015, 2:41 AM
 */

//System Library
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries 

//Global Constants 

//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {

    char loop; 
    do{
       //Declare variables 
        float year_HD,now_HD, infla_rate; 
        
        cout<<"Enter the price of a hot dog today =";
        cin>>now_HD;
        cout<<"Enter the price of a hot dog 1 year ago =";
        cin>>year_HD;
   
    //Calculate inflation 
        infla_rate= ((now_HD-year_HD)/year_HD)*100;
        
        //Output
        cout<<"The rate of inflation is "<<infla_rate<<"%"<<endl;
        cout << "Enter Y to continue or N to exit: ";
        cin >> loop;
    
   }while (loop == 'Y' || loop == 'y');
    cout << "Finished" << endl;

   
    return 0;
}


