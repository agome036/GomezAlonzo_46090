/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Calculating average 
 * Created on July 24, 2015, 5:49 PM
 */

//System Library
#include <fstream>
#include <iostream>
#include <cstdlib>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype
void s_min_min(ifstream& in_stream, ofstream& out_stream);
//Execution Begins Here!
int main(int argc, char** argv) {
    ifstream in_stream;
    ofstream out_stream;
    
    cout << "Begin editing files.\n";
   
    in_stream.open("file1.dat");
    
     
    if(in_stream.fail())     
    {
      cout << "Input file opening failed.\n";          
      exit(1);
           cout << "Input file opening failed.\n";
           exit(1);       
    }
       out_stream.open("outdata.dat");
    if(out_stream.fail( ))
       {           
        cout << "Output file opening failed.\n";
           exit(1);
       }
       
       s_min_min(in_stream,out_stream);
  
            in_stream.close();
           out_stream.close();
           cout << "End of editing files.\n";
    return 0;
}
void s_min_min(ifstream& in_stream, ofstream& out_stream)
{
    char next;
    
    while(!in_stream.eof())
    {
        if (next==' ')
            out_stream<<" ";
        else 
            out_stream<<next;
        in_stream.get(next);
    }
}

