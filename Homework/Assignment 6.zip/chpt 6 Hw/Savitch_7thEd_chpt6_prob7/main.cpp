/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Calculating average 
 * Created on July 23, 2015, 8:49 PM
 */

//System Library
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype

//Execution Begins Here!
int main(int argc, char** argv) {

    ifstream in_stream1;
    ifstream in_stream2;
    ofstream out_stream; 
    
    in_stream1.open("file1.dat");
    in_stream2.open("file2.dat");
    out_stream.open("outfile.dat");
    
    int first, second, third, fourth, fifth, sixth, seventh ,eighth, ninth, ten;
    
    in_stream1>>first>>second>>third>>fourth>>fifth;
    in_stream2>>sixth>>seventh>>eighth>>ninth>>ten;
    
    out_stream<< " The combination of the two files is"<<endl
     <<first<<second<<third<<fourth<<fifth<<sixth<<seventh<<eighth<<ninth<<ten<<endl
            <<endl;
    
    in_stream1.close();
    in_stream2.close();
    out_stream.close();
 
    return 0;
}

