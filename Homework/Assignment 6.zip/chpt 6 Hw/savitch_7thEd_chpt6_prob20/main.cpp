/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Word Count
 * Created on July 24, 2015, 7:36 PM
 */

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype

//Execution Begins Here!
int main(int argc, char** argv) {

    ifstream in_stream; 
    string fileName;
    string word;
    int count = 0;
    
    cout<<"Please enter file.dat for this assignment"<<endl;
    cout << "Please enter the file name ";
    getline(cin,fileName);
    

    in_stream.open(fileName.c_str());

    while(!in_stream.eof())
    {               
        in_stream >> word; 
        count++;
    }

    cout << "Number of words in file is " << count;
    in_stream.close();

    cin.get();  
    return 0;
}

