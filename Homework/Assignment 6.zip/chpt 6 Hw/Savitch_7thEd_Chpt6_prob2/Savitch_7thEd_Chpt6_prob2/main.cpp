/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Finding highest/lowest value 
 * Created on July 22, 2015, 12:58 PM
 */

//System Library
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries 

//Global Constants

//Function Prototype 
void filAray(int [],int);
void prntAry(const int [],int,int);
//Execution Begins Here!
int main(int argc, char** argv) {
     //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=5;
    int array[SIZE];
    
    
    //Call functions
     filAray(array,SIZE);
     int count; 
    int highest;
    int lowest;
   
    
    //To find the highest value 
    highest=array[0];
     for (count = 1; count < SIZE; count++){
 if (array[count] > highest)
 highest = array[count];
     
     }
    cout<<"The highest number in the array is "<<highest<<endl;
     
    //To find the lowest value 
    lowest = array[0];
for (count = 1; count < SIZE; count++)
{
 if (array[count] < lowest)
 lowest = array[count];
 
 
}
    cout<<"The lowest number in the array is "<<lowest<<endl;
 
     
     prntAry(array,SIZE,20);
     
    
    
    return 0;
}
/**************************************************
 *                Fill Array                      *
 **************************************************
 * Purpose:  To fill an array with 2 digit integer
 *           random numbers.
 * Input:
 *    n-> The size of the array
 * Input-Output:
 *    a-> The integer Array
 * Output:
 */
void filAray(int a[],int n){
    //Loop on every element and equate to 2 digits
    for(int i=0;i<n;i++){
        a[i]=rand()%90+10;//[10-99]
    }
}
/**************************************************
 *                Print Array                      *
 **************************************************
 * Purpose:  To print an integer array with any
 *           number of columns
 * Input:
 *    n-> The size of the array
 *    a-> The integer Array
 *    nCols->Number of columns to display the array.
 * Output:
 *    On Screen
 */
void prntAry(const int a[],int n,int nCols){
    //Separate outputs with a line
    cout<<endl;
    //Loop and output every element in the array
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        //When column is reached go to next line
        if((i%nCols)==(nCols-1))cout<<endl;
    }
    //Separate outputs with a line
    cout<<endl;
    int SIZE=5;
float average, sum = 0;
for(int i = 0; i < SIZE;i++)
sum += a[i];

average = sum / SIZE;

cout<<"The average is "<<average<<endl;
}