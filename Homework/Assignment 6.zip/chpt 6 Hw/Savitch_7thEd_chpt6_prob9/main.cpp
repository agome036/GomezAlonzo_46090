/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Calculating average 
 * Created on July 23, 2015, 8:49 PM
 */

//System Library#include <iostream> 
#include <fstream> 

using namespace std; 

int main() 
{ 
    int n; 
    ifstream in_stream;  
    ofstream out_stream; 
    
    in_stream.open("num.txt");  
    
    if(in_stream.fail( ))
    { 
        cout << "error opening input file"<<endl; 
        return 1;
    }
    
    out_stream.open("average.txt"); 
    
    if(out_stream.fail( )) 
    {    
        cout << "error opening output file"<<endl; 
        return 0; 
    } 

     
    int total=0;
    int count=0;

    while(!in_stream.eof())
    {
        in_stream>>n;
        total=total+n;
        count++;
    }

    float average=0;

    average=float(total)/float(count); 
    cout<<"sum "<<total<<" count "<<count<<" average "<<average;
    out_stream<<" Gomez Alonzo 4 6 7 9 6 7 8 4 6 4  The average is "<<average<<endl;
    
    in_stream.close();     
    out_stream.close(); 
    
    return 0;

}  
