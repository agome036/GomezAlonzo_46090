/* 
 * File:   main.cpp
 * Author: Alonzo Gomez 
 * Purpose: Blackjack Project
 * Created on July 28, 2015, 7:02 PM
 */

//System Library
#include <cstdlib>// srand and rand
#include <iostream>// I/O
#include <ctime>// Generate random numbers
#include <cctype>// Used for lower and upper case letters
#include <iomanip>// setprecision
#include <fstream>
using namespace std;

//User Libraries 

//Global Constants 

//Function Prototype 

//Assigning cards for player and dealer
void Cards(int &, int &, int &, int &);
//Simulating dealer's turn
int dealer(int &, int &);
// results from dealer's turn
float results(int &, int &,float &,int &, int &, int &, float [],int);

//Execution Begins Here!

int main(int argc, char** argv) {
//Declare all variables
    const int SIZE=100;//maximum size of array
    float AryBet[SIZE];//array to hold bet values
    AryBet[0]=0;//initialize bet array
    int count=0;
    int plCard1 = 1;   //Player Card 1
    int plCard2 = 1;   //Player Card 2
    int dlCard1 = 1;    //Dealer Card 1
    int dlCard2 = 1;    //Dealer Card 2
    int playSum;  //Sum of player cards
    int dealSum;  //Sum of dealer cards
    int option;  //Used for main menu
    int plyCard=1;  //Additional card that player gets when he hits
    int dlCard=1;  //dealer hit
    int win=0;  //to count wins
    int lose=0;  //to count losses
    int tie=0;  //to count ties
    char another;  //Another game
    char answer='H';   //Option to hit or stay
    char answ;   //Used for About Blackjack menu
    bool loop=true;  //Used for do-while loop around main menu
    bool menu;   //Used for About Blackjack do-while loop
    bool game=true;  //Used for do-while loop around entire main function
    float bet;
    float total=0;
    ofstream out_stream;
    
    //Output Main Menu
    cout<<"Thank you for choosing Blackjack"<<endl;
    cout<<endl;
    cout<<" What would you like to do?"<<endl;
    cout<<endl;
    cout<<"1. Play Blackjack"<<endl;
    cout<<"2. Blackjack Background"<<endl;
    cout<<"3. Exit"<<endl;
    cin>>option;
    
     //Loop needed to ask if user would like to play again
    do{
        //Loop main menu until told to exit
        do{
	
	if(option == 1){
		//Starting game
        cout<<"Starting Game"<<endl;
        cout<<setprecision(2)<<fixed<<showpoint;
        cout<<"You have $"<<total+5000<<endl;
        cout<<"Place your bet: $";
        cin>>bet;
        count++;
          
                
        //Maintain arbitrary limit of $5000
        
        while (bet>total+5000||bet<0){
            cout<<"Please enter a bet in the range of your current balance."<<endl;
            cout<<"$";
            cin>>bet;
        }       
        
        //Call getCards function to generate cards 
        Cards (plCard1, plCard2, dlCard1, dlCard2);
        cout<<"Your cards are "<<plCard1 + 1<<" and "<<plCard2 +1<< " = " << plCard1 + plCard2 + 2 << endl << endl;
        cout<<"The dealer has "<<dlCard1 + 1<<" and "<<"???"<< " = " << dlCard1 + 1<< endl << endl;
		loop=false;//End the loop                
	}
        
	else if(option==2){
			
        //Output About Blackjack Menu
        cout<<"Blackjack Background"<<endl;
        cout<<"1. Rules"<<endl;
        cout<<"2. Vocabulary"<<endl;
	cout<<"3. Exit Menu"<<endl;
	cin>>answ;

		//Initialize menu to keep loop going until told not to
        menu=true;
        do{
    switch(answ){
    case '1'://Rules
        cout<<"You will start with a balance of $5000 dollars, then player will place bet"<<endl;
          cout<<"The dealer will give you two cards and himself two, one card face down."<<endl;
          cout<<"Once you have your two cards, you can choose to hit or stay."<<endl;
          cout<<"The goal is to get as close to 21 while having a higher total then"<<endl;
          cout<<"the dealer.If your cards equal 21,(BLACKJACK!) you automatically win."<<endl;
          cout<<"If your sum is greater than the dealers sum, you win."<<endl;
          cout<<"If the dealers sum is greater than your sum you lose."<<endl;
          cout<<"If your sums are equal, then it is a tie."<<endl;
          menu=false;
            break;					
                                               
    case '2'://Vocabulary
          cout<<"Hit: player wants another card."<<endl;
          cout<<"Stand: player okay with cards in hand."<<endl;
          cout<<"Bust: Going over 21."<<endl;
          cout<<"Push: Tie "<<endl;
          cout<<"Bet: Amount of money willing to risk in order to gain"<<endl;
               menu=false;
                            break;
                                                
    case '3'://Back to main menu
          cout<<"Welcome to the game of Blackjack"<<endl;
          cout<<"1. Play Blackjack"<<endl;
          cout<<"2. Blackjack Background"<<endl;
          cout<<"3. Exit"<<endl;
         cin>>option ;
         menu=false;
		break;
		}
	}while(menu==true);
	}
	else {
		cout<<"Ok. Thank you for playing."<<endl;
		loop=false;
        exit(0);//To terminate game
		cout<<endl;	
	}
	}while(loop==true);

	//Calculate player's and dealer's sums
    playSum = plCard1 + plCard2 + 2;
	dealSum = dlCard1 + dlCard2 + 2;

	if(playSum==21)
		cout<<"Congratulations!You won!"<<endl;
        
	else if(playSum<21){
		do{
            while (playSum < 21){
			cout<<"Would you like to hit or stay? (H/S)"<<endl;
			cin>>answer;
                        
			if(toupper(answer)=='H'){
				
                //Set random number seed
                    srand(time(0));
                    plyCard=rand()%10;
                    playSum+=plyCard+1;
                                
                //Output new card
				cout<<"Your new card is "<<plyCard+1<<endl;
				cout<<"Your new total is "<<playSum<<endl;
                                
                if(playSum==21){
                    cout<<endl;
                    cout<<"Congratulations!"<<endl;
                    cout<<" You won $"<<bet<<endl;
                    win++;
                    AryBet[count]=bet;
                    total+=AryBet[count];
                   
                }
                
                else if (playSum > 21)
                {
                    cout<<endl;
                    cout<<"Sorry, you busted."<<endl;
                    cout<<"You lost $"<<bet<<endl;
                    bet*=-1;
                            AryBet[count]=bet;
                    lose++;
                    total+=AryBet[count];
                    if(total+5000<=0)
                    {
                        cout<<"You have ran out of money. Thank you for playing";
                        cout<<" Goodbye."<<endl;
                        
                        system("PAUSE");
                        exit(0);
                    }
                   
                }
                
                else {
                    cout <<' '<<endl;
                }
			}
                        
			else if(toupper(answer)=='S'){
				
                //Output final total
                cout<<"Your final total is "<<playSum<<endl;
				cout<<endl;
                                
                //Dealers turn 
                cout<<"Dealers Turn."<<endl;
                loop=false;
                
                dealer(dealSum,dlCard);
                
                //Get Results from dealers turn
                results(dealSum, playSum,bet, win, lose, tie,AryBet,count);
                
                //resulting options
                if(win++)
                    AryBet[count]=bet;
                else if (lose++){
                    bet*=1;
                    AryBet[count]=bet;
                }
                else if(tie++)
                   AryBet[count]=0;
                
                //Calculate sum of bet array
                total+=AryBet[count];
                
                //End game if player is broke
                if(total+5000<=0)
                    {
                        cout<<"Unfortunately, you ran out of money. Thanks for playing. Goodbye."<<endl;
                        system("PAUSE");
                        exit(0);
                    }                                
                // prompt for another hand
                goto Again;
			}
                        
			else
				cout<<endl;
                    }
                    
			}while(playSum<21);
        }
        
	else{
            cout<<endl;
            cout<<"Sorry. You busted."<<endl;
        }
        
        //Prompt if user wants another hand
        Again: cout<<"Would you like to play another hand? Y/N"<<endl;
        cin>>another;
        
        if(toupper(another)=='Y')
            game=true;
        
        else if (toupper(another)=='N')
        {
            cout<<"Ok. Thank you for playing."<<endl;
            game=false;
          //open file and output the player's money
            out_stream.open("results.txt");
            if(out_stream.is_open())
            {
                out_stream<<setprecision(2)<<fixed<<showpoint;
                out_stream<<"You finished the game with $"<<total+5000<<endl;
                out_stream.close();
                cout<<"Go check the results.txt file"<<endl;
            }
            else
            {
                //In case the file doesn't open
                cout<<"Unable to open file."<<endl;
            }  
           
        } 
        
        
        
    }while(game==true);

    
    //Exit stage right!
    return 0;
}

/*******************************************************************************
 ************************Generate Cards*****************************************
 *******************************************************************************
 *Purpose: To get the cards for the player and dealer
 *Input: Random number generator 
 *Output: Two cards for each player && dealer
 */
void Cards( int & plyCard1, int & plyCard2, int & dlCard1, int & dlCard2)
{
    //Set random number seed
    srand(time(0));
    
    //Generate cards for player and dealer
    plyCard1=rand()%11;
    plyCard2=rand()%10;
    dlCard1=rand()%11;
    dlCard2=rand()%10;
}

/*******************************************************************************
 ************************Simulate Dealers Turn**********************************
 *******************************************************************************
 *Purpose: To determine if the dealer should hit || stay
 *Output: Dealers new card sum
 */

int dealer(int &dlSum, int &dlCard)
{    
    //Set random number seed
    srand(time(0));
    
    //Determine if dealer needs to hit
    while (dlSum<17){
        dlCard=rand()%10;
        dlSum+=dlCard+1;
        cout<<"The dealers new card is "<<dlCard+1<<endl;
        cout<<"The dealers new total is "<<dlSum<<endl;
    }
    return dlCard, dlSum;
}

/*******************************************************************************
 **************************Result of Dealer turn********************************
 *******************************************************************************
 *Purpose: Compare player and dealer hands
 *Output: Who won the hand of Blackjack
 */

float results(int &dealSum, int &playSum, float &bet, int &win, int &lose, int &tie, float AryBet[], int count)
{    
    //Output Results of turn
    if(dealSum>21)
    {
        cout<<fixed<<setprecision(2)<<showpoint;
        cout<<endl;
        cout<<"Dealer busted."<<endl;
        cout<<"You won $"<<bet<<endl<<endl;
        bet*=1;
        AryBet[count]=bet;
        win++;
        return win, AryBet[count];
       
        
    }
    else if(dealSum>playSum)
    {
        cout<<endl;
        cout<<"Sorry. The dealer won."<<endl;
        cout<<"You lost $"<<bet<<endl;
        bet*=-1;
        AryBet[count]=bet;
        lose++;
        return lose, AryBet[count];
       
    }
    else if(playSum>dealSum)
    {
        cout<<endl;
        cout<<"Congratulations!"<<endl;
        cout<<"You won $"<<bet<<endl;
       bet*=1;
       AryBet[count]=bet;
        win++;
        return win, AryBet[count];
        
    }
    else if(playSum==dealSum)
    {
        cout<<endl;
        cout<<"It was a tie.(push)"<<endl;
        cout<<" You get your money back."<<endl;
        bet=0;
        AryBet[count]=bet;
        tie++;
        return tie, AryBet[count];
    }
    else
        cout<<"Error!"<<endl;
}  
         


